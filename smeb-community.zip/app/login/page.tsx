import React from 'react'

const Login = () => {
  return (
    <div>
      this is login
      <button className="btn btn-neutral">Neutral</button>
    </div>
  )
}

export default Login
