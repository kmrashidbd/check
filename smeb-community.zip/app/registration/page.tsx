import React from 'react'

const Register = () => {
  return (
    <div>
      this is register
    </div>
  )
}

export default Register
